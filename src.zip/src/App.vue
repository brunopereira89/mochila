<template>
  <div id="app">
    <Header />
    <blog />
    <Footer />
  </div>
</template>

<script>
import blog from "./components/Blog"
import Header from './components/Header'
import Footer from './components/Footer'
//import axios from 'axios'

export default {
  name: 'App',
  components: {
  blog,
  Header,
  Footer
  },
/* data(){
    return{
      blog:[]
    }
  },

  created(){
    axios.get('https://jsonplaceholder.typicode.com/posts?userId=1')
      .then(response=> this.blog = response.data)
      .catch(error => console.log(error));
  }
*/

}
</script>

<style lang="scss">
  $main-font:Arial, sans-serif;
  *{
    box-sizing:border-box;
    margin:0;
    padding:0;
  }

  body {
    font-family: $main-font;
    line-height: 1.4;
  }

</style>
