<template>
        <div class="footer">
            <div class="fcontainer">
              <p class="ftexto">Copyright © 2020</p>
            </div>
        </div>
</template>

<script>
export default {
  name: 'Footer'
}
</script>


<style lang="scss" scoped>
$bgcolor : rgb(27, 36, 65);


  .footer{
    padding: 30px 20px;
    background-color: $bgcolor;
    clear:both;
 
        .fcontainer{
            max-width: 1200px;
            margin: 0 auto;
            color:white;
            text-align: center;
        }

  }
</style> 