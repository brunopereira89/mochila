<template>
        <div class="cabecalho">
            <div class="hcontainer">
                <h1>Blog Posts</h1>
            </div>
        </div>
</template>

<script>
export default {
  name: 'Header'
}
</script>


<style lang="scss" scoped>
$bgcolor : rgb(27, 36, 65);


  .cabecalho{
    padding: 30px 20px;
    background-color: $bgcolor;
 
        .hcontainer{
            max-width: 1200px;
            margin: 0 auto;
            color:white;
        }
  }
</style> 