<template>
  <div class="posts">
      <div v-for="(post, index) in exercicio" :key=index>
        <div class="minicontainer">
          <img class="imagem" src="../assets/logo.png">
          <div class="txtcontainer">
            <h2 class="titulos">{{post.title}}</h2>
            <transition name="fade">
              <p class="texto" v-show="isHidden"> {{post.body}}</p>
            </transition> 
            <div style="text-align:center;">
              <button class="link" @click="toggleTxt()" v-if="!isHidden">Ler mais</button>
              <button class="link" @click="toggleTxt()" v-if="isHidden">Esconder</button>
            </div>
          </div>
      </div>
    </div>

  </div>
</template>

<script>
//import axios from 'axios';
import exercicio from '../assets/exercicio.json';

export default {
  name: 'Blog',

   data(){
    return{
      exercicio,
      isHidden:false
    }
  },

  methods:{
    toggleTxt:function(){
      this.isHidden ^=true;
    }
  }
 
}
</script>


<style lang="scss" scoped>
  .posts{
    max-width: 1200px;
    margin:60px auto 10px auto;

      .minicontainer{
        float:left;
        border:#ddd solid 1px;
        width:48%;
        margin: 10px ;

          .txtcontainer{
            background-color:#f0f0f0;
            padding: 30px;
          }

          .imagem{
            width:100%;
          }

          .titulos{
            min-height: 70px;
          }


          .link{
            color:white;
            font-weight: bold;
            margin-top:20px;
            background-color: blue;
            padding: 10px 25px;
            border:solid 1px blue;
            border-radius: 5px;
            cursor: pointer;
          }
      }
  }

.fade-enter-active, .fade-leave-active {
  transition: opacity .5s;
}
.fade-enter, .fade-leave-to {
  opacity: 0;
}

@media screen and (max-width:1110px){
  .posts{
    .minicontainer{
      float: left;
    width:46%;
    margin:20px;
    .titulos{
            min-height: 120px;
          }
  }
  }
}
@media screen and (max-width:999px){
  .posts{
    .minicontainer{
      float: left;
    width:45%;
    margin:20px;
    .titulos{
            min-height: 120px;
          }
  }
  }
}

@media screen and (max-width:880px){
  .posts{
    .minicontainer{
      float: none;
    width:96%;
    margin:20px auto;
    .titulos{
            min-height: 70px;
          }
  }
  }
}



</style> 