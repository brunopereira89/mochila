var convert = require('./convert'),
    func = convert('noop', require('../noop'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
