var convert = require('./convert'),
    func = convert('minBy', require('../minBy'));

func.placeholder = require('./placeholder');
module.exports = func;
