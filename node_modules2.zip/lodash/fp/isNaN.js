var convert = require('./convert'),
    func = convert('isNaN', require('../isNaN'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
