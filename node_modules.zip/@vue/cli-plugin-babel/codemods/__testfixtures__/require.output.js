const config = {
  presets: [
    [require('@vue/cli-plugin-babel/preset'), {
      polyfills: []
    }]
  ]
}

module.exports = config
